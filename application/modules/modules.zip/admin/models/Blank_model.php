<?php

if (!defined('BASEPATH'))
    EXIT("No direct script access allowed");

class Blank_model extends MY_Model {

    function __construct() {
        parent::__construct();
    }

}

?>